import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Check, Clipboard, Clock3, Lock, RefreshCw, Trophy } from 'lucide-react';
import { supabase } from './supabaseClient';
import { fetchWeeklyGames } from './services/cfbApi';
import { getCurrentWeekNumber, getCurrentWeekString, isGameLocked } from './utils/getCurrentWeek';
import { calculateStandings, LEAGUE_MEMBERS } from './utils/leaderboard';
import { copyPicksToClipboard } from './utils/exportHelpers';
import PickMatrix from './components/PickMatrix';

const SEASON = 2026;

export default function App() {
  const [selectedUser, setSelectedUser] = useState('Austin');
  const [selectedWeek, setSelectedWeek] = useState(getCurrentWeekString());
  const [games, setGames] = useState([]);
  const [picks, setPicks] = useState({});
  const [allLeaguePicks, setAllLeaguePicks] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [apiError, setApiError] = useState(null);

  const weekNum = Number(selectedWeek.replace('Week ', '')) || getCurrentWeekNumber();
  // The pool's Week 5 aligns with CFBD's Week 4 (our pool starts on Wednesday).
  const cfbdWeek = Math.max(1, weekNum - 1);

  const lockedGame = useMemo(() => {
    const lockedId = Object.keys(picks).find((id) => picks[id]?.isLock);
    return games.find((game) => String(game.id) === String(lockedId));
  }, [games, picks]);

  async function loadGames() {
    setIsLoading(true);
    setApiError(null);
    try {
      const liveGames = await fetchWeeklyGames(SEASON, cfbdWeek);
      setGames(liveGames);
      if (!liveGames.length) {
        setApiError(`No games were returned for ${selectedWeek} (CFBD Week ${cfbdWeek}). Check the CFBD API key and season/week settings.`);
      }
    } catch (error) {
      console.error(error);
      setGames([]);
      setApiError(error.message);
    } finally {
      setIsLoading(false);
    }
  }

  async function loadPicks() {
    const { data, error } = await supabase.from('user_picks').select('*').eq('week', weekNum);
    if (error) {
      console.error(error);
      setApiError((current) => current || `Supabase error: ${error.message}`);
      return;
    }
    setAllLeaguePicks(data || []);
    const currentUserData = (data || []).find((row) => row.user_name === selectedUser);
    setPicks(currentUserData?.picks || {});
  }

  useEffect(() => { loadGames(); }, [cfbdWeek]);
  useEffect(() => { loadPicks(); }, [weekNum, selectedUser]);

  useEffect(() => {
    const picksChannel = supabase
      .channel(`public:user_picks:week_${weekNum}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'user_picks', filter: `week=eq.${weekNum}` }, (payload) => {
        if (!payload.new?.user_name) return;
        const updatedRow = payload.new;
        setAllLeaguePicks((prev) => {
          const idx = prev.findIndex((row) => row.user_name === updatedRow.user_name);
          if (idx === -1) return [...prev, updatedRow];
          const copy = [...prev];
          copy[idx] = updatedRow;
          return copy;
        });
        if (updatedRow.user_name === selectedUser) setPicks(updatedRow.picks || {});
      })
      .subscribe();
    return () => { supabase.removeChannel(picksChannel); };
  }, [weekNum, selectedUser]);

  async function savePicks(nextPicks) {
    setPicks(nextPicks);
    setIsSaving(true);
    const { error } = await supabase.from('user_picks').upsert(
      { user_name: selectedUser, week: weekNum, picks: nextPicks, updated_at: new Date().toISOString() },
      { onConflict: 'user_name,week' }
    );
    setIsSaving(false);
    if (error) setApiError(`Could not save picks: ${error.message}`);
  }

  async function handlePick(gameId, spreadChoice) {
    const nextPicks = { ...picks, [gameId]: { ...picks[gameId], spread: spreadChoice } };
    await savePicks(nextPicks);
  }

  async function handleLockToggle(targetGameId) {
    const isCurrentlyLocked = picks[targetGameId]?.isLock || false;
    const updatedPicks = {};
    Object.keys(picks).forEach((gameId) => {
      updatedPicks[gameId] = { ...picks[gameId], isLock: false };
    });
    if (!isCurrentlyLocked) {
      updatedPicks[targetGameId] = { ...updatedPicks[targetGameId], isLock: true };
    }
    await savePicks(updatedPicks);
  }

  const standings = calculateStandings(allLeaguePicks, games);
  const pickedCount = Object.values(picks).filter((pick) => pick?.spread).length;
  const completedCount = games.filter((game) => game.status === 'FINAL').length;

  return (
    <div className="app-shell">
      <main className="mx-auto max-w-6xl px-4 py-5 sm:px-6 sm:py-8">
        <header className="mb-5 surface rounded-2xl p-4 sm:p-6">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.22em] text-red-400">
                <span className="h-2 w-2 rounded-full bg-red-500" /> 2026 Season
              </div>
              <h1 className="text-3xl font-black tracking-tight text-white sm:text-4xl">Bama Bois Pick 'Em</h1>
              <p className="mt-1 text-sm text-slate-400">Pick against the spread. One lock. Bragging rights.</p>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:flex">
              <label className="relative">
                <span className="sr-only">Member</span>
                <select className="select-control w-full" value={selectedUser} onChange={(e) => setSelectedUser(e.target.value)}>
                  {LEAGUE_MEMBERS.map((member) => <option key={member}>{member}</option>)}
                </select>
              </label>
              <label className="relative">
                <span className="sr-only">Week</span>
                <select className="select-control w-full" value={selectedWeek} onChange={(e) => setSelectedWeek(e.target.value)}>
                  {Array.from({ length: 14 }, (_, i) => <option key={i + 1}>Week {i + 1}</option>)}
                </select>
              </label>
            </div>
          </div>
        </header>

        <section className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Week" value={weekNum} />
          <Stat label="Your picks" value={`${pickedCount}/${games.length || 10}`} />
          <Stat label="Final" value={completedCount} />
          <Stat label="Lock" value={lockedGame ? 'SET' : 'OPEN'} accent={Boolean(lockedGame)} />
        </section>

        <section className={`mb-5 flex flex-col gap-3 rounded-2xl border p-4 sm:flex-row sm:items-center sm:justify-between ${lockedGame ? 'border-amber-500/30 bg-amber-500/10' : 'border-slate-700 bg-slate-900/70'}`}>
          <div className="flex items-start gap-3">
            <div className={`mt-0.5 rounded-full p-2 ${lockedGame ? 'bg-amber-500/15 text-amber-400' : 'bg-slate-800 text-slate-400'}`}>
              {lockedGame ? <Lock size={18} /> : <AlertTriangle size={18} />}
            </div>
            <div>
              <p className="font-bold text-white">{lockedGame ? 'Lock of the week is set' : 'No lock selected yet'}</p>
              <p className="text-sm text-slate-400">
                {lockedGame ? `${lockedGame.awayTeam} @ ${lockedGame.homeTeam}` : 'Choose a game after making your pick.'}
              </p>
            </div>
          </div>
          <button
            onClick={() => copyPicksToClipboard(selectedUser, selectedWeek, picks, games)}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-red-600 px-4 py-2.5 font-bold text-white transition hover:bg-red-500 active:scale-[.99]"
          >
            <Clipboard size={17} /> Copy Picks
          </button>
        </section>

        {apiError && (
          <section className="mb-5 rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-red-100">
            <div className="flex gap-3">
              <AlertTriangle className="mt-0.5 shrink-0 text-red-400" size={20} />
              <div className="min-w-0">
                <p className="font-bold">Game data needs attention</p>
                <p className="mt-1 text-sm text-red-200/80">{apiError}</p>
                <button onClick={loadGames} className="mt-3 inline-flex items-center gap-2 rounded-lg border border-red-400/30 bg-red-500/10 px-3 py-2 text-sm font-bold hover:bg-red-500/20">
                  <RefreshCw size={15} /> Retry
                </button>
              </div>
            </div>
          </section>
        )}

        <section className="mb-8">
          <div className="mb-3 flex items-end justify-between">
            <div>
              <h2 className="text-xl font-black text-white sm:text-2xl">Your picks</h2>
              <p className="text-sm text-slate-500">Tap a side to pick. Picks lock at kickoff.</p>
            </div>
            {isSaving && <span className="text-xs font-semibold text-slate-500">Saving…</span>}
          </div>

          {isLoading ? (
            <div className="grid gap-3 sm:grid-cols-2">
              {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-40 animate-pulse rounded-2xl bg-slate-900" />)}
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {games.map((game) => {
                const lockedByKickoff = isGameLocked(game.startDate);
                const currentPick = picks[game.id]?.spread;
                const lineLabel = (line) => line == null ? 'OFF' : line > 0 ? `+${line}` : line;
                return (
                  <article key={game.id} className={`game-card rounded-2xl p-4 ${lockedByKickoff ? 'opacity-75' : ''}`}>
                    <div className="mb-3 flex items-center justify-between text-xs font-bold uppercase tracking-wide">
                      <span className="inline-flex items-center gap-1.5 text-slate-500"><Clock3 size={14} /> {game.time}</span>
                      {lockedByKickoff ? <span className="text-amber-400">Locked</span> : game.isBama ? <span className="text-red-400">Bama Game</span> : <span className="text-slate-600">Open</span>}
                    </div>
                    <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
                      <PickButton selected={currentPick === 'away'} disabled={lockedByKickoff || game.awaySpread == null} onClick={() => handlePick(game.id, 'away')}>
                        <span className="block truncate text-sm font-black sm:text-base">{game.awayAbbr}</span>
                        <span className="text-xs font-semibold text-slate-400">{lineLabel(game.awaySpread)}</span>
                      </PickButton>
                      <span className="text-xs font-black text-slate-600">@</span>
                      <PickButton selected={currentPick === 'home'} disabled={lockedByKickoff || game.homeSpread == null} onClick={() => handlePick(game.id, 'home')}>
                        <span className="block truncate text-sm font-black sm:text-base">{game.homeAbbr}</span>
                        <span className="text-xs font-semibold text-slate-400">{lineLabel(game.homeSpread)}</span>
                      </PickButton>
                    </div>
                    <button
                      disabled={lockedByKickoff || !currentPick}
                      onClick={() => handleLockToggle(game.id)}
                      className={`lock-button mt-3 flex w-full items-center justify-center gap-2 rounded-xl border text-sm font-black ${picks[game.id]?.isLock ? 'border-amber-400/40 bg-amber-500/15 text-amber-300' : 'border-slate-700 bg-slate-900 text-slate-400 hover:border-slate-500 hover:text-slate-200'} disabled:cursor-not-allowed disabled:opacity-40`}
                    >
                      {picks[game.id]?.isLock ? <><Lock size={15} /> LOCK OF THE WEEK</> : 'Set as Lock'}
                    </button>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        <section className="mb-8">
          <SectionHeading icon={<Check size={18} />} title="Who Picked Who" subtitle="See the whole league at a glance." />
          <div className="surface rounded-2xl p-2 sm:p-3"><PickMatrix games={games} allLeaguePicks={allLeaguePicks} /></div>
        </section>

        <section>
          <SectionHeading icon={<Trophy size={18} />} title="Live Standings" subtitle="1 point per win. Your lock is worth an extra point." />
          <div className="surface overflow-hidden rounded-2xl">
            <div className="mobile-scroll">
              <table className="w-full text-left">
                <thead className="bg-slate-900 text-xs uppercase tracking-wide text-slate-500">
                  <tr><th className="px-4 py-3">Rank</th><th className="px-4 py-3">Member</th><th className="px-4 py-3">W-L-P</th><th className="px-4 py-3">Lock</th><th className="px-4 py-3 text-right">Points</th></tr>
                </thead>
                <tbody>
                  {standings.map((member, idx) => (
                    <tr key={member.userName} className="border-t border-slate-800 text-sm">
                      <td className="px-4 py-4 font-black text-slate-500">{idx + 1}</td>
                      <td className="px-4 py-4 font-bold text-white">{member.userName}{member.userName === selectedUser && <span className="ml-2 rounded-full bg-red-500/10 px-2 py-1 text-[10px] font-black uppercase text-red-400">You</span>}</td>
                      <td className="px-4 py-4 font-semibold text-slate-300">{member.wins}-{member.losses}-{member.pushes}</td>
                      <td className="px-4 py-4">{member.lockWon ? <span className="font-black text-emerald-400">WON +1</span> : member.lockLost ? <span className="font-black text-red-400">LOST</span> : <span className="text-slate-600">PENDING</span>}</td>
                      <td className="px-4 py-4 text-right text-lg font-black text-white">{member.totalPoints}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function Stat({ label, value, accent = false }) {
  return <div className="surface rounded-2xl px-4 py-3"><p className="text-[11px] font-black uppercase tracking-wider text-slate-500">{label}</p><p className={`mt-1 text-xl font-black ${accent ? 'text-amber-300' : 'text-white'}`}>{value}</p></div>;
}

function SectionHeading({ icon, title, subtitle }) {
  return <div className="mb-3 flex items-center gap-3"><div className="rounded-xl bg-red-500/10 p-2 text-red-400">{icon}</div><div><h2 className="text-xl font-black text-white sm:text-2xl">{title}</h2><p className="text-sm text-slate-500">{subtitle}</p></div></div>;
}

function PickButton({ selected, disabled, onClick, children }) {
  return <button disabled={disabled} onClick={onClick} className={`pick-button rounded-xl px-3 text-center ${selected ? 'selected' : ''}`}>{children}</button>;
}
