import { Lock } from 'lucide-react';
import { LEAGUE_MEMBERS } from '../utils/leaderboard';

export default function PickMatrix({ games, allLeaguePicks }) {
  const picksByMember = {};
  allLeaguePicks.forEach((row) => { picksByMember[row.user_name] = row.picks || {}; });

  return (
    <div className="mobile-scroll overflow-hidden rounded-xl">
      <table className="w-full min-w-[720px] text-sm text-left">
        <thead className="bg-slate-900 text-xs uppercase tracking-wide text-slate-500">
          <tr>
            <th className="px-3 py-3">Matchup</th>
            {LEAGUE_MEMBERS.map((member) => <th key={member} className="px-3 py-3 text-center">{member}</th>)}
          </tr>
        </thead>
        <tbody>
          {games.map((game) => (
            <tr key={game.id} className="border-t border-slate-800">
              <td className="whitespace-nowrap px-3 py-3 font-bold text-slate-300">{game.awayAbbr} <span className="text-slate-600">@</span> {game.homeAbbr}</td>
              {LEAGUE_MEMBERS.map((member) => {
                const pick = picksByMember[member]?.[game.id];
                if (!pick?.spread) return <td key={member} className="px-3 py-3 text-center text-slate-700">—</td>;
                const teamName = pick.spread === 'home' ? game.homeAbbr : game.awayAbbr;
                return <td key={member} className={`px-3 py-3 text-center font-black ${pick.isLock ? 'text-amber-300' : 'text-slate-300'}`}>{teamName} {pick.isLock && <Lock className="inline" size={12} />}</td>;
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
