export async function fetchWeeklyGames(year = 2026, week = 1) {
  const response = await fetch(`/api/cfb?year=${encodeURIComponent(year)}&week=${encodeURIComponent(week)}`);
  const body = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(body.error || `CFBD request failed (${response.status})`);
  }

  return (body.games || []).map((game) => ({
    ...game,
    time: game.startDate
      ? new Date(game.startDate).toLocaleString('en-US', {
          weekday: 'short',
          hour: 'numeric',
          minute: '2-digit',
        })
      : 'TBD',
  }));
}
