// The pool's week windows intentionally start on Wednesday so the league can
// review the next Saturday slate. CFBD's official week number is one behind
// the pool number for the current season after Week 1.
const WEEK_SCHEDULE = [
  { week: 1, start: '2026-08-26', end: '2026-09-02' },
  { week: 2, start: '2026-09-02', end: '2026-09-09' },
  { week: 3, start: '2026-09-09', end: '2026-09-16' },
  { week: 4, start: '2026-09-16', end: '2026-09-23' },
  { week: 5, start: '2026-09-23', end: '2026-09-30' },
  { week: 6, start: '2026-09-30', end: '2026-10-07' },
  { week: 7, start: '2026-10-07', end: '2026-10-14' },
  { week: 8, start: '2026-10-14', end: '2026-10-21' },
  { week: 9, start: '2026-10-21', end: '2026-10-28' },
  { week: 10, start: '2026-10-28', end: '2026-11-04' },
  { week: 11, start: '2026-11-04', end: '2026-11-11' },
  { week: 12, start: '2026-11-11', end: '2026-11-18' },
  { week: 13, start: '2026-11-18', end: '2026-11-25' },
  { week: 14, start: '2026-11-25', end: '2026-12-02' },
];

function localDate(dateString) {
  const [year, month, day] = dateString.split('-').map(Number);
  return new Date(year, month - 1, day);
}

export function getCurrentWeekNumber() {
  const now = new Date();
  const current = WEEK_SCHEDULE.find((week) => now >= localDate(week.start) && now < localDate(week.end));
  return current?.week ?? 5;
}

export function getCurrentWeekString() {
  return `Week ${getCurrentWeekNumber()}`;
}

export function isGameLocked(gameStartDate) {
  return Boolean(gameStartDate) && new Date() >= new Date(gameStartDate);
}
