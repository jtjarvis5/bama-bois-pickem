# Bama Bois Pick'em — Vercel deployment

## 1. Import the repo into Vercel

- Framework preset: **Vite**
- Build command: `npm run build`
- Output directory: `dist`
- Install command: `npm install`

## 2. Add environment variables

### Production + Preview

```text
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
CFBD_API_KEY=YOUR_COLLEGEFOOTBALLDATA_API_KEY
```

**Important:** `CFBD_API_KEY` must NOT start with `VITE_`. It is now read only by `/api/cfb.js`, so it is not shipped to the browser.

College Football Data's current documentation explicitly says API keys should be kept out of public browser applications and sent as a Bearer token from server-side code.

## 3. Supabase

The existing app still uses the league-member dropdown (`Austin`, `Bama1`, etc.) so the current database can be used without changing the existing table immediately.

Before treating the app as tamper-resistant, migrate `user_picks` to Supabase Auth and RLS. A starter security note is in `supabase/production-security.sql`.

## 4. CFBD week mapping

The pool's week starts Wednesday, while the CFBD schedule is using the official football week. For this season, the app maps:

```text
Pool Week 5 -> CFBD Week 4
Pool Week 6 -> CFBD Week 5
...
```

That is why the old hardcoded `weekNum = 3` behavior produced the wrong/no-game response. The app now derives the pool week from the selector and sends the corresponding CFBD week to the server-side function.

## 5. Test after deployment

Open:

```text
/api/cfb?year=2026&week=4
```

You should receive JSON containing the selected games. If you see `CFBD_API_KEY is not configured on Vercel`, add the environment variable and redeploy.

If you see a CFBD `401`, the API key is missing/invalid. If you see a quota/entitlement response, check the CFBD account access. Those response classes are documented by CFBD.
