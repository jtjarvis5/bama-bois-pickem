const BASE_URL = 'https://api.collegefootballdata.com';

export default async function handler(req, res) {
  const { year = '2026', week = '1' } = req.query || {};
  const apiKey = process.env.CFBD_API_KEY;

  if (!apiKey) {
    return res.status(500).json({ error: 'CFBD_API_KEY is not configured on Vercel.' });
  }

  const yearNum = Number(year);
  const weekNum = Number(week);
  if (!Number.isInteger(yearNum) || !Number.isInteger(weekNum) || weekNum < 1 || weekNum > 20) {
    return res.status(400).json({ error: 'Invalid year or week.' });
  }

  const params = new URLSearchParams({
    year: String(yearNum),
    week: String(weekNum),
    seasonType: 'regular',
  });

  try {
    const headers = { Authorization: `Bearer ${apiKey}` };
    const [gamesRes, linesRes] = await Promise.all([
      fetch(`${BASE_URL}/games?${params}`, { headers }),
      fetch(`${BASE_URL}/lines?${params}`, { headers }),
    ]);

    if (!gamesRes.ok) {
      const body = await gamesRes.text();
      return res.status(gamesRes.status).json({
        error: `CFBD games request failed (${gamesRes.status}).`,
        details: body.slice(0, 500),
      });
    }

    const gamesData = await gamesRes.json();
    const linesData = linesRes.ok ? await linesRes.json() : [];

    const linesMap = {};
    if (Array.isArray(linesData)) {
      linesData.forEach((item) => {
        const lineObj = item.lines?.find((line) => line.provider === 'Bovada') || item.lines?.[0];
        if (lineObj && typeof lineObj.spread === 'number') {
          linesMap[item.id] = { spread: lineObj.spread };
        }
      });
    }

    const formattedGames = gamesData.map((game) => {
      const line = linesMap[game.id] || { spread: null };
      const homeSpread = line.spread;
      const awaySpread = homeSpread == null ? null : -homeSpread;
      const isBama = game.homeTeam === 'Alabama' || game.awayTeam === 'Alabama';

      let winningSpreadTeam = null;
      if (game.completed && homeSpread != null && game.homePoints != null && game.awayPoints != null) {
        const homeMargin = game.homePoints - game.awayPoints;
        if (homeMargin + homeSpread > 0) winningSpreadTeam = 'home';
        else if (homeMargin + homeSpread < 0) winningSpreadTeam = 'away';
        else winningSpreadTeam = 'push';
      }

      return {
        id: game.id,
        isBama,
        homeTeam: game.homeTeam,
        awayTeam: game.awayTeam,
        homeAbbr: abbreviate(game.homeTeam),
        awayAbbr: abbreviate(game.awayTeam),
        homeSpread,
        awaySpread,
        startDate: game.startDate,
        status: game.completed ? 'FINAL' : 'UPCOMING',
        homePoints: game.homePoints,
        awayPoints: game.awayPoints,
        winningSpreadTeam,
      };
    });

    const bamaGame = formattedGames.find((game) => game.isBama);
    const otherGames = formattedGames.filter((game) => !game.isBama).slice(0, 9);
    const selectedGames = bamaGame ? [bamaGame, ...otherGames] : formattedGames.slice(0, 10);

    return res.status(200).json({ year: yearNum, week: weekNum, games: selectedGames });
  } catch (error) {
    return res.status(500).json({ error: 'Unable to reach College Football Data API.', details: error.message });
  }
}

function abbreviate(team = '') {
  const known = {
    Alabama: 'ALA',
    'South Carolina': 'SC',
    Georgia: 'UGA',
    Texas: 'TEX',
    Tennessee: 'TENN',
    LSU: 'LSU',
    Auburn: 'AUB',
    Florida: 'FLA',
    'Ole Miss': 'MISS',
    'Mississippi State': 'MSST',
    Oklahoma: 'OU',
    Missouri: 'MIZ',
    'Texas A&M': 'TAMU',
  };
  return known[team] || team.split(/\s+/).map((word) => word[0]).join('').slice(0, 4).toUpperCase();
}
